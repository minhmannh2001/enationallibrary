$(function() {
	'use strict';

	
  $('.form-control').on('input', function() {
	  var $field = $(this).closest('.form-group');
	  if (this.value) {
	    $field.addClass('field--not-empty');
	  } else {
	    $field.removeClass('field--not-empty');
	  }
	});

});

document.addEventListener('DOMContentLoaded', function () {
	let username_input = document.getElementById("username");
	console.log(username_input.value.length);
	if (username_input.value.length > 0) {
		var $field = $(this).closest('.form-group');
		$field.addClass('field--not-empty');
	}
});